import taichi as ti
import numpy as np
import math
import matplotlib.pyplot as plt
import xlsxwriter
import sys
import pandas as pd

sys.path.append("..") 

# import materials
from materials.drucker_prager import *

# ti.init(arch=ti.gpu, default_fp=ti.f64) # use GPU
ti.init(arch=ti.cpu, default_fp=ti.f64) # use CPU


# ============ PARTICLES, GRID QUANTITIES ============
n_s_particles = ti.field(dtype=int, shape=())
max_num_s_particles = 25600  
n_grid = 800 

max_x = 8.0 
dx, inv_dx = max_x/n_grid, float(n_grid/max_x) 
dt = 5e-5 
t_total = 1 
N = t_total/dt
print('dx =', dx)
print('inv_dx', inv_dx)


dim = 2 

# Constants
standard_gravity = ti.Vector([0, -9.81]) 


# Column collapse geometry (initial geometry sizes. Please see Fig. 2 in [Neto, Borja, ActaGeo, 2018])
d0 = 0.2 
h0 = 1.6 
center_line_x = n_grid * dx / 2
start_x = center_line_x - d0 


n_particles_per_direction = 2
PPC = n_particles_per_direction**dim 
p_vol = 1*dx**dim/PPC 
s_vol = 1*p_vol*max_num_s_particles
t_vol = 1*d0*2*h0 


# Sand particles quantities
x_s = ti.Vector.field(dim, dtype=float, shape=max_num_s_particles) 
v_s = ti.Vector.field(dim, dtype=float, shape=max_num_s_particles) 
Affine_C_s = ti.Matrix.field(dim, dim, dtype=float, shape=max_num_s_particles)

# my input
stress_buffer = ti.Vector.field(dim, dtype=float, shape=max_num_s_particles)

rho_s = 2.7 
mass_s = p_vol * rho_s 


# Sand material parameters
soil_E = 2.016e4 
soil_Poisson = 0.3 
soil_friction_angle = 30 


# MPM schemes parameters
FLIP_blending_ratio = 0.95
APIC_flag = True


# # Grids quantities
grid_sv = ti.Vector.field(dim, dtype=float, shape=(n_grid, n_grid)) 
grid_old_sv = ti.Vector.field(dim, dtype=float, shape=(n_grid, n_grid)) 
grid_sm = ti.field(dtype=float, shape=(n_grid, n_grid)) 
grid_sf = ti.Vector.field(dim, dtype=float, shape=(n_grid, n_grid)) 



# ====================================================


# ============ LOAD STEP ============
@ti.kernel
def load_step(step: ti.i32):
	gravity = min(500, step)/500 * standard_gravity 

	# reset grid quantities
    # beofore P2G, grid has no quantities
    # for each grid 
	for i, j in grid_sm:
		# 2D
		grid_sv[i, j] = [0, 0] 
		grid_old_sv[i, j] = [0, 0] 
		grid_sm[i, j] = 0 
		grid_sf[i, j] = [0, 0] 



	# P2G, partcile to grid
	for p in range(n_s_particles[None]): 
		base = (x_s[p] * inv_dx - 0.5).cast(int) 
		fx = x_s[p] * inv_dx - base.cast(float) 

		# Quadratic B-spline kernels, Eq. (123) in [MPM SIGGRAPH 2016 course]
		w = [0.5 * (1.5 - fx) ** 2, 0.75 - (fx - 1) ** 2, 0.5 * (fx - 0.5) ** 2]


		# get stress
		stress_3D = sand_material.get_Cauchy_stress(p) # get sand Cauchy stress (3D)
		stress = ti.Matrix.zero(float, dim, dim)
		
		for i, j in ti.static(ti.ndrange(dim, dim)):
			stress[i, j] = stress_3D[i, j]
			stress_buffer = stress     

        

		# get affine
		affine = Affine_C_s[p]

		# get particle new volume
		particle_new_volume = p_vol * sand_material.get_J(p)


		# perform P2G
		for i, j in ti.static(ti.ndrange(3, 3)):
			offset = ti.Vector([i, j])
			dpos = (offset.cast(float) - fx) * dx 
			weight = w[i][0] * w[j][1]
			grid_sv[base + offset] += weight * (mass_s * v_s[p]) 
			if (APIC_flag):
				grid_sv[base + offset] += weight * mass_s * affine @ dpos 
			grid_sm[base + offset] += weight * mass_s
			grid_sf[base + offset] += weight * (-particle_new_volume * 4 * inv_dx * inv_dx) * stress @ dpos 
			


	# Explicit solver
	for i, j in grid_sm:
		if grid_sm[i, j] > 0:
			grid_sv[i, j] = (1 / grid_sm[i, j]) * grid_sv[i, j] 
			grid_old_sv[i, j] = grid_sv[i, j]

		# Velocity update
		if grid_sm[i, j] > 0:
			grid_sv[i, j] += dt * (gravity + grid_sf[i, j] / grid_sm[i, j])


		# BCs (change normal v to zero)
		if grid_sm[i, j] > 0:
			if i < 3 and grid_sv[i, j][0] < 0:
				grid_old_sv[i, j][0] = 0
				grid_sv[i, j][0] = 0
			if i > n_grid - 3 and grid_sv[i, j][0] > 0: 
				grid_old_sv[i, j][0] = 0
				grid_sv[i, j][0] = 0

			if j < 3:
				grid_old_sv[i, j][0] = 0
				grid_old_sv[i, j][1] = 0
				grid_sv[i, j][0] = 0
				grid_sv[i, j][1] = 0
                
			if j > n_grid - 3 and grid_sv[i, j][1] > 0:
				grid_old_sv[i, j][1] = 0
				grid_sv[i, j][1] = 0

			if (i*dx-0.5*dx <= start_x or i*dx+0.5*dx >= start_x + 2*d0) and (step < 500):
				grid_old_sv[i, j][0] = 0
				grid_sv[i, j][0] = 0 



	# G2P, grid to particle
	for p in range(n_s_particles[None]):
		base = (x_s[p] * inv_dx - 0.5).cast(int)
		fx = x_s[p] * inv_dx - base.cast(float)
		w = [0.5 * (1.5 - fx) ** 2, 0.75 - (fx - 1.0) ** 2, 0.5 * (fx - 0.5) ** 2]
		new_PIC_v = ti.Vector.zero(float, dim)
		new_FLIP_v = v_s[p]
		new_C = ti.Matrix.zero(float, dim, dim)
		for i, j in ti.static(ti.ndrange(3, 3)):
			offset = ti.Vector([i, j])
			dpos = (offset.cast(float) - fx) * dx
			g_v = grid_sv[base + offset]
			g_old_v = grid_old_sv[base + offset]
			weight = w[i][0] * w[j][1]

			new_PIC_v += weight * g_v 
			new_FLIP_v += weight * (g_v - g_old_v)
			new_C += 4 * weight * g_v.outer_product(dpos) * inv_dx ** 2 



		delta_F = (ti.Matrix.identity(float, dim) + dt * new_C) 
		# update material
		sand_material.update_deformation_gradient(delta_F, p)


		# particle advection 
		v_s[p] = FLIP_blending_ratio * new_FLIP_v + (1 - FLIP_blending_ratio) * new_PIC_v
		Affine_C_s[p] = new_C
		x_s[p] += dt * new_PIC_v



# ============ INITIALIZATION ============
sand_material = DruckerPrager(n_particles=max_num_s_particles, dim=2, E=soil_E, nu=soil_Poisson, friction_angle=soil_friction_angle)

@ti.kernel
def initialize():
	n_s_particles[None] = 0
	# material initialization
	sand_material.initialize()


	# Homogeneous initialization (2x2 PPC)
	new_particle_id = 0
	for i, j in grid_sm:
		if i*dx >= start_x and i*dx < start_x + 2*d0 and j >= 2 and j*dx < 2*dx + h0:

			for index_x in range(0, n_particles_per_direction):
				for index_y in range(0, n_particles_per_direction):
					new_particle_id = ti.atomic_add(n_s_particles[None], 1)
					x_s[new_particle_id] = [i * dx + (0.5+index_x) * dx/n_particles_per_direction, j * dx + (0.5+index_y) * dx/n_particles_per_direction]
					v_s[new_particle_id] = ti.Matrix([0,0]) 






# ============ MAIN LOOP ============
# initialization
initialize()


# export file
export_file = '../post_processing/dry_sand_collapse.ply'
time_data = open("../data_0/time.txt","w")


total_step = 0
current_time = 0 
while current_time<=0.05:
    for step in range(50):
        total_step += 1
        load_step(total_step)

	# Show time
    current_time = float(max(total_step-500, 0) *dt)
    
    
	## Export ply file
    writer = ti.tools.PLYWriter(num_vertices=max_num_s_particles)
    x_s_to_numpy = x_s.to_numpy()
    writer.add_vertex_pos(current_time*np.ones(max_num_s_particles), x_s_to_numpy[:, 0], x_s_to_numpy[:, 1]) 
    writer.export_frame_ascii(total_step, export_file)

    
    #export time file    
    time_data.write("%s\n" % f'{current_time:.5f}')   
time_data.close() 





