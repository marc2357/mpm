import taichi as ti
import numpy as np

# ti.init(arch=ti.gpu)
# ti.init(arch=ti.gpu, default_fp=ti.f64)
ti.init(arch=ti.cpu, default_fp=ti.f64)

# constants
pi = 3.141592653
tol = 1e-8 #1e-10

@ti.data_oriented
class DruckerPragerRheology:
    def __init__(self,
                 n_particles, # number of particles
                 dim, # problem dimension, 2 = 2D (plain strain assumption), 3 = 3D
                 E, # Young's modulus
                 nu, # Poisson's ratio
                 friction_angle, # friction angle in degree unit
                 cohesion, # cohesion TODO: check
                 mu_2, # mu_2 parameter for rheology
                 xi, # xi parameter for rheology
                 implicit_rheology_flag, # implicit or explicit flag for rheology
                 shape_factor # shape factor for tip smoothening
                 ):
        self.n_particles = n_particles
        self.dim = dim
        self.E = E
        self.nu = nu
        self.lame_mu, self.lame_lambda = E / (2*(1+nu)), E*nu / ((1+nu) * (1-2*nu)) # Lame parameters
        self.K = E / (3*(1.0-2.0*nu))
        self.friction_angle = friction_angle
        self.cohesion = cohesion

        # Rheology parameters
        self.mu_2 = mu_2
        self.xi = xi
        self.implicit_rheology_flag = implicit_rheology_flag
        self.shape_factor = shape_factor

        # Quantities declaration (some of them will be initialized in another funciton)
        self.F_elastic_array = ti.Matrix.field(3, 3, dtype = float, shape = n_particles)
        self.J_array = ti.field(dtype = float, shape = n_particles)
        self.J_no_bar_array = ti.field(dtype = float, shape = n_particles)
        self.friction_coeff_array = ti.field(dtype = float, shape = n_particles)
        self.cohesion_array = ti.field(dtype = float, shape = n_particles)
        self.plastic_multiplier = ti.field(dtype = float, shape = n_particles)
        self.plastic_rate = ti.field(dtype = float, shape = n_particles)
        self.SFLIP_beta_FLAG = ti.field(dtype = float, shape = n_particles)

        self.P_array = ti.field(dtype=float, shape=n_particles)
        self.Q_array = ti.field(dtype=float, shape=n_particles) # For return mapping convenience

        self.elastic_a = ti.Matrix.field(3, 3, dtype=float, shape=()) # tangent for principal values

    # ============ MEMBER FUNCTIONS - taichi scope ============
    @ti.func
    def initialize(self):
        F_elastic_init = ti.Matrix.identity(float, 3)

        for p in range(self.n_particles):
            self.F_elastic_array[p] = F_elastic_init

            self.J_array[p] = 1.0
            self.J_no_bar_array[p] = 1.0

            self.friction_coeff_array[p] = 2.0*ti.sqrt(6)*ti.sin(self.friction_angle*pi/180) / (3-ti.sin(self.friction_angle*pi/180)) # B in Eq. (4.76) of [Borja, Plasticity Modeling & Computation]
            self.cohesion_array[p] = self.cohesion #0.0
            self.plastic_multiplier[p] = 0.0
            self.plastic_rate[p] = 0.0
            self.SFLIP_beta_FLAG[p] = 0 # 1:BETA MIN 2:BETA MAX

            self.P_array[p] = 0.0
            self.Q_array[p] = 0.0


        # initialize elastic_a
        elastic_a_tmp = self.lame_lambda * ti.Matrix([[1.0, 1.0, 1.0], [1.0, 1.0, 1.0], [1.0, 1.0, 1.0]])
        elastic_a_tmp += 2.0 * self.lame_mu * ti.Matrix.identity(float, 3)
        self.elastic_a[None] = elastic_a_tmp




    @ti.func
    def return_mapping(self, e_trial, p, dt):
        # # old implementation
        # e_trial = e_trial_0 # not consider volume correction

        # ehat = e_trial - e_trial.trace()/3 * ti.Matrix.identity(float, 3) # Eq. (27) in [ref paper 1]
        # ehat_norm = ti.sqrt(ehat[0, 0] ** 2 + ehat[1, 1] ** 2 + ehat[2, 2] ** 2)

        # delta_lambda = ehat_norm + (3 * self.lame_lambda + 2 * self.lame_mu) / (2 * self.lame_mu) * e_trial.trace() * self.friction_coeff_array[p] # Eq. (27) in [ref paper 1]

        # new_e = ti.Matrix.zero(float, 3, 3)
        # delta_q = 0.0
        
        
        # # three cases
        # if ehat_norm <= 0 or e_trial.trace() > 0: # case II, project to the tip
        #     self.SFLIP_beta_FLAG[p] = 1 # if not tension, we use beta min to approximate FLIP
        #     new_e = ti.Matrix.zero(float, 3, 3)
        #     e_trial_norm = ti.sqrt(e_trial[0, 0] ** 2 + e_trial[1, 1] ** 2 + e_trial[2, 2] ** 2)
        #     delta_q = e_trial_norm

        #     self.plastic_multiplier[p] += delta_lambda
        #     self.plastic_rate[p] = delta_lambda / dt
        #     # TODO: state
        # elif delta_lambda <= 0: # case I, elastic
        #     self.SFLIP_beta_FLAG[p] = 1 # if elastic, we use beta min to approximate FLIP
        #     new_e = e_trial_0
        #     delta_q = 0.0
        #     self.plastic_rate[p] = 0.0
        #     # TODO: state
        # else: # case III, plastic

        #     # self.plastic_multiplier[p] += delta_lambda
        #     # # TODO: state
        #     self.SFLIP_beta_FLAG[p] = 2 # if plastic, we use beta max to approximate NFLIP
        #     # Rheology
        #     eps_v = e_trial.trace()
        #     tau_trial = self.lame_lambda * eps_v * ti.Matrix.identity(float, 3) + 2 * self.lame_mu * e_trial

        #     p_trial = 1/3 * tau_trial.trace() # compression negative
        #     S_trial = tau_trial - p_trial * ti.Matrix.identity(float, 3)
        #     S_trial_norm = ti.sqrt(S_trial[0, 0] ** 2 + S_trial[1, 1] ** 2 + S_trial[2, 2] ** 2)
        #     equiv_tau_trial = S_trial_norm / ti.sqrt(2)


        #     mu_s = 1.0/ti.sqrt(2) * 3 * self.friction_coeff_array[p]

        #     new_equiv_tau = 0.0

        #     # new_equiv_tau  = (-p_trial) * mu_s / ti.sqrt(2) # no rheology, just for checking the implementation

        #     # # implicit rheoloty
        #     if (self.implicit_rheology_flag):
        #         S0 = mu_s * (-p_trial)
        #         S2 = self.mu_2 * (-p_trial)
        #         alpha = self.xi * self.lame_mu * dt * ti.sqrt(-p_trial)
        #         B = S2 + equiv_tau_trial + alpha
        #         H = S2 * equiv_tau_trial + S0 * alpha

        #         # solve for tau_n+1
        #         new_equiv_tau = (B-ti.sqrt(B*B - 4*H)) / 2


        #     else:
        #         # explicit rheology
        #         current_mu = mu_s
        #         if (self.plastic_rate[p] > tol):
        #             current_mu = mu_s + (self.mu_2 - mu_s) / (self.xi*ti.sqrt(-p_trial)/(ti.sqrt(2)*self.plastic_rate[p]) + 1)
        #         new_equiv_tau = (-p_trial) * current_mu / ti.sqrt(2)


        #     # get new strains
        #     delta_lambda = (equiv_tau_trial - new_equiv_tau) / (ti.sqrt(2)*self.lame_mu)
        #     new_e = e_trial - delta_lambda / ehat_norm * ehat

        #     self.plastic_rate[p] = delta_lambda / dt

        #     self.plastic_multiplier[p] += delta_lambda


        # return new_e







        # new implementation
        # Calculate trial stress
        eps_v = e_trial.trace()
        tau_trial = self.lame_lambda * eps_v * ti.Matrix.identity(float, 3) + 2 * self.lame_mu * e_trial

        # Get P and S
        P = 1/3 * tau_trial.trace()
        S_trial = tau_trial - P * ti.Matrix.identity(float, 3)
        S_trial_norm = ti.sqrt(S_trial[0, 0] ** 2 + S_trial[1, 1] ** 2 + S_trial[2, 2] ** 2)
        equiv_tau_trial = S_trial_norm / ti.sqrt(2) # see the definition in (2.10) of [Dunatunga, Kamrin, JFM, 2015]
        Q_trial = ti.sqrt(3.0/2.0) * S_trial_norm

        new_e = ti.Matrix.zero(float, 3, 3)


        mu_s = self.friction_coeff_array[p] / ti.sqrt(2)


        # return mapping
        yield_function = ti.sqrt(2.0/3.0) * Q_trial + self.friction_coeff_array[p] * P

        if yield_function <= 0: # elastic
            new_e = e_trial
        elif yield_function > 0 and e_trial.trace() > 0: # plasticity, return mapping to the tip
            delta_lambda = ti.sqrt(e_trial[0,0]**2 + e_trial[1,1]**2 + e_trial[2,2]**2) # TODO: confirm this

            new_e = ti.Matrix.zero(float, 3, 3)

            self.plastic_multiplier[p] += delta_lambda
            self.plastic_rate[p] = delta_lambda / dt
            self.J_array[p] = 1.0
            self.J_no_bar_array[p] = 1.0

        elif yield_function > 0: # plasticity, radial return mapping with dilation angle = 0
            
            # Implicit rheology
            new_equiv_tau = 0.0

            S0 = mu_s * (-P)
            S2 = self.mu_2 * (-P)
            alpha = self.xi * self.lame_mu * dt * ti.sqrt(-P)
            B = S2 + equiv_tau_trial + alpha
            H = S2 * equiv_tau_trial + S0 * alpha

            # solve for tau_n+1
            new_equiv_tau = (B-ti.sqrt(B*B - 4*H)) / 2 # the solution of Eq. (3.14) in [Dunatunga, Kamrin, JFM, 2015] 

            # get new strains
            delta_lambda = (equiv_tau_trial - new_equiv_tau) / (ti.sqrt(2)*self.lame_mu)

            # radial direction
            n = ti.Matrix.zero(float, 3, 3)
            if S_trial_norm > 0:
                n = S_trial / S_trial_norm

            new_e = e_trial - delta_lambda * n

            self.plastic_rate[p] = delta_lambda / dt
            self.plastic_multiplier[p] += delta_lambda


        return new_e




    @ti.func
    def update_deformation_gradient(self, delta_F, p, dt):
        
        # delta_F_3D = ti.Matrix.zero(float, 3, 3)
        # if self.dim == 2:
        #     for i, j in ti.static(ti.ndrange(2, 2)):
        #         # new_C_3D[i, j] = new_C[i, j]
        #         delta_F_3D[i, j] = delta_F[i, j]
        #     # new_C_3D[2, 2] = 0.0
        #     delta_F_3D[2, 2] = 1.0
        # else:
        #     for i, j in ti.static(ti.ndrange(self.dim, self.dim)):
        #         # new_C_3D[i, j] = new_C[i, j]
        #         delta_F_3D[i, j] = delta_F[i, j]

        # # new_F_elastic_trial = (ti.Matrix.identity(float, 3) + dt * new_C_3D) @ self.F_elastic_array[p]
        # new_F_elastic_trial = delta_F_3D @ self.F_elastic_array[p]

        # # update J
        # delta_J = delta_F_3D.determinant()
        # self.J_array[p] *= delta_J


        # U, sig, V = ti.svd(new_F_elastic_trial)
        # e = ti.Matrix.zero(float, 3, 3)
        # for d in ti.static(range(3)):
        #     e[d, d] = ti.log(sig[d, d])
        # self.SFLIP_beta_FLAG[p] = 2 # by default, we use beta max to approximate NFLIP
        # new_e = self.return_mapping(e, p, dt)


        # # get new elastic deformation gradient
        # exp_new_e = ti.Matrix.zero(float, 3, 3)
        # for d in ti.static(range(3)):
        #     exp_new_e[d, d] = ti.exp(new_e[d, d])
        # new_F_elastic = U @ exp_new_e @ V.transpose()


        # # update elastic deformation gradient
        # self.F_elastic_array[p] = new_F_elastic









        # New implementation with local iteration

        # get trial state
        delta_F_3D = ti.Matrix.zero(float, 3, 3)
        if self.dim == 2:
            for i, j in ti.static(ti.ndrange(2, 2)):
                delta_F_3D[i, j] = delta_F[i, j]
            delta_F_3D[2, 2] = 1.0
        else:
            for i, j in ti.static(ti.ndrange(self.dim, self.dim)):
                delta_F_3D[i, j] = delta_F[i, j]

        new_F_elastic_trial = delta_F_3D @ self.F_elastic_array[p]

        # update J
        delta_J = delta_F_3D.determinant()
        self.J_array[p] *= delta_J


        # SVD decomposition to get principal logarithmic strain
        U, sig, V = ti.svd(new_F_elastic_trial)
        e_trial = ti.Vector.zero(float, 3)
        for d in ti.static(range(3)):
            e_trial[d] = ti.log(sig[d, d])

        # assume real e to be trial e
        e_real = e_trial

        # Check yield
        principal_stresses = self.grad_Psi(e_trial, p)
        yield_y = self.yield_function(p)

        # print('principal_stresses: ', principal_stresses) # test correct
        # print('yield: ', yield_y) 


        if yield_y < tol:
            # elastic
            self.F_elastic_array[p] = new_F_elastic_trial
        else:
            # plastic

            print('Yield')

            # local newton iteration
            xdelta = ti.Vector.zero(float, 4)
            residual = ti.Vector.zero(float, 4)
            jacobian = ti.Matrix.zero(float, 4, 4)

            delta_lambda = 0.0 # initial guess
            for local_iter in range(15):
                grad_g = self.grad_potential(principal_stresses, p)
                grad_f = self.grad_yield(principal_stresses, p)
                grad_f_eps = self.grad_yield_epsilon(grad_f)

                hess_g = self.hess_potential(principal_stresses, p)
                hess_g_eps = self.hess_potential_epsilon(hess_g)

                # print(hess_g_eps)

                print('grad_g:', grad_g) # this is nan if the material is under tension

                # assemble residual
                for i in ti.static(range(3)):
                    residual[i] = e_real[i] - e_trial[i] + delta_lambda * grad_g[i]

                residual[3] = self.yield_function(p)

                # check for convergence
                if residual.norm() < tol:
                    print('No. of iteration: ', local_iter)
                    break


                # assemble jacobian
                for i, j in ti.static(ti.ndrange(3, 3)):
                    jacobian[i, j] = delta_lambda * hess_g_eps[i, j]
                    if i == j:
                        jacobian[i, j] += 1.0

                for i in ti.static(range(3)):
                    jacobian[i, 3] = grad_g[i]

                for i in ti.static(range(3)):
                    jacobian[3, i] = grad_f_eps[i]


                # Solve the local return mapping equation
                xdelta = jacobian.inverse() @ residual

                # print('xdelta:', xdelta)

                # Update quantities
                for i in ti.static(range(3)):
                    e_real[i] -= xdelta[i]

                delta_lambda -= xdelta[3]


                # Update stress
                principal_stresses = self.grad_Psi(e_real, p)


                if local_iter == 14:
                    print('Not converge!', 'residual value:', residual.norm())


            # Upon convergence, obtain the elastic deformation gradient
            # get new elastic deformation gradient
            exp_new_e = ti.Matrix.zero(float, 3, 3)
            for d in ti.static(range(3)):
                exp_new_e[d, d] = ti.exp(e_real[d])
            new_F_elastic = U @ exp_new_e @ V.transpose()

            self.F_elastic_array[p] = new_F_elastic






    # Gradient of energy density function
    # [Input]: principal strains
    # [Output]: principal stresses
    @ti.func
    def grad_Psi(self, principal_e, p):
        eps_v = principal_e[0] + principal_e[1] + principal_e[2]
        eps_s = ti.sqrt(2.0/9.0 * ((principal_e[0]-principal_e[1])**2 + (principal_e[1]-principal_e[2])**2 + (principal_e[0]-principal_e[2])**2) )

        self.P_array[p] = self.K * eps_v
        self.Q_array[p] = 3.0 * self.lame_mu * eps_s

        principal_stresses = ti.Vector.zero(float, 3)

        principal_stresses[0] = self.P_array[p] + 2.0/3.0 * self.lame_mu * (2*principal_e[0] - principal_e[1] - principal_e[2])
        principal_stresses[1] = self.P_array[p] + 2.0/3.0 * self.lame_mu * (2*principal_e[1] - principal_e[0] - principal_e[2])
        principal_stresses[2] = self.P_array[p] + 2.0/3.0 * self.lame_mu * (2*principal_e[2] - principal_e[0] - principal_e[1])

        return principal_stresses


    # Yield function
    # [Output]: yield value. Negative for elasticity, positive for yielding
    @ti.func 
    def yield_function(self, p):
        cos_angle = ti.cos(self.friction_angle*pi/180)
        sin_angle = ti.sin(self.friction_angle*pi/180) # TODO: currently, we do not consider the softening or hardening

        A = 2*ti.sqrt(6) * self.cohesion_array[p] * cos_angle / (3.0 - sin_angle)
        B = 2*ti.sqrt(6) * sin_angle / (3.0 - sin_angle)


        omega_F = 2.0/3.0 * self.Q_array[p]**2 + self.shape_factor**2 * A**2


        return ti.sqrt(omega_F) - (A - B*self.P_array[p])

    

    # Gradient potential function w.r.t. principal stresses
    # [Input]: principal stresses
    # [Output]: gradient of potential function 
    @ti.func 
    def grad_potential(self, principal_stresses, p):
        cos_dilation = 1.0
        sin_dilation = 0.0

        A = 2*ti.sqrt(6) * self.cohesion_array[p] * cos_dilation / (3.0 - sin_dilation)
        B = 2*ti.sqrt(6) * sin_dilation / (3.0 - sin_dilation)

        omega_F = 2.0/3.0 * self.Q_array[p]**2 + self.shape_factor**2 * A**2

        # print('omega_F:', omega_F)

        dFdP = B
        dFdQ = 2.0/3.0 * self.Q_array[p] / ti.sqrt(omega_F) # becareful of 0

        Q_with_threshold = self.Q_array[p]
        sign_Q = 1.0
        if Q_with_threshold < 0.0:
            sign_Q = -1.0
        if ti.abs(Q_with_threshold) < tol:
            Q_with_threshold = tol * sign_Q

        gradQ = ti.Vector.zero(float, 3)
        gradQ[0] = 0.5/Q_with_threshold * (2.0*principal_stresses[0] - principal_stresses[1] - principal_stresses[2])
        gradQ[1] = 0.5/Q_with_threshold * (2.0*principal_stresses[1] - principal_stresses[0] - principal_stresses[2])
        gradQ[2] = 0.5/Q_with_threshold * (2.0*principal_stresses[2] - principal_stresses[0] - principal_stresses[1])

        # print('Q_with_threshold:', Q_with_threshold)

        grad_g = ti.Vector.zero(float, 3)
        grad_g[0] = dFdP*1.0/3.0 + dFdQ*gradQ[0]
        grad_g[1] = dFdP*1.0/3.0 + dFdQ*gradQ[1]
        grad_g[2] = dFdP*1.0/3.0 + dFdQ*gradQ[2]

        return grad_g


    # Gradient yield function w.r.t. principal stresses
    # [Input]: principal stresses
    # [Output]: gradient of yield function
    @ti.func 
    def grad_yield(self, principal_stresses, p):
        cos_angle = ti.cos(self.friction_angle*pi/180)
        sin_angle = ti.sin(self.friction_angle*pi/180) # TODO: currently, we do not consider the softening or hardening

        A = 2*ti.sqrt(6) * self.cohesion_array[p] * cos_angle / (3.0 - sin_angle)
        B = 2*ti.sqrt(6) * sin_angle / (3.0 - sin_angle)

        omega_F = 2.0/3.0 * self.Q_array[p]**2 + self.shape_factor**2 * A**2

        dFdP = B
        dFdQ = 2.0/3.0 * self.Q_array[p] / ti.sqrt(omega_F)

        Q_with_threshold = self.Q_array[p]
        sign_Q = 1.0
        if Q_with_threshold < 0.0:
            sign_Q = -1.0
        if ti.abs(Q_with_threshold) < tol:
            Q_with_threshold = tol * sign_Q

        gradQ = ti.Vector.zero(float, 3)
        gradQ[0] = 0.5/Q_with_threshold * (2.0*principal_stresses[0] - principal_stresses[1] - principal_stresses[2])
        gradQ[1] = 0.5/Q_with_threshold * (2.0*principal_stresses[1] - principal_stresses[0] - principal_stresses[2])
        gradQ[2] = 0.5/Q_with_threshold * (2.0*principal_stresses[2] - principal_stresses[0] - principal_stresses[1])

        grad_f = ti.Vector.zero(float, 3)
        grad_f[0] = dFdP*1.0/3.0 + dFdQ*gradQ[0]
        grad_f[1] = dFdP*1.0/3.0 + dFdQ*gradQ[1]
        grad_f[2] = dFdP*1.0/3.0 + dFdQ*gradQ[2]

        return grad_f


    # Partial yield function / partial principal strains
    # [Input]: grad of yield function w.r.t. principal stresses
    # [Output]: Partial yield / partial principal strains
    @ti.func 
    def grad_yield_epsilon(self, grad_f):
        grad_f_eps = ti.Vector.zero(float, 3)

        for a, i in ti.static(ti.ndrange(3, 3)):
            grad_f_eps[i] += grad_f[a] * self.elastic_a[None][a, i]

        return grad_f_eps


    # Second derivative of potential function w.r.t. principal stresses
    # [Input]: principal stresses
    # [Output]: second derivative
    @ti.func
    def hess_potential(self, principal_stresses, p):
        # The implementation heavily follows the implementation of Geocentric

        # calculate S
        S = ti.Vector.zero(float, 3)
        S[0] = principal_stresses[0] - self.P_array[p]
        S[1] = principal_stresses[1] - self.P_array[p]
        S[2] = principal_stresses[2] - self.P_array[p]

        trS2 = S.dot(S)
        chi = ti.sqrt(trS2)
        if ti.abs(chi) < tol:
            chi = tol
        const1 = ti.sqrt(3.0/2.0) / chi

        gradQ = const1 * S

        hessQ = ti.Matrix.zero(float, 3, 3)
        for a, b in ti.static(ti.ndrange(3, 3)):
            if a == b:
                hessQ[a, b] = const1 * ( 1.0 - 1.0/3.0 - S[a]*S[b]/(chi**2) )
            else:
                hessQ[a, b] = const1 * ( 0.0 - 1.0/3.0 - S[a]*S[b]/(chi**2) )

        cos_dilation = 1.0
        sin_dilation = 0.0

        A = 2*ti.sqrt(6) * self.cohesion_array[p] * cos_dilation / (3.0 - sin_dilation)
        B = 2*ti.sqrt(6) * sin_dilation / (3.0 - sin_dilation)

        omega_F = 2.0/3.0 * self.Q_array[p]**2 + self.shape_factor**2 * A**2

        dFdQ = 2.0/3.0 * self.Q_array[p] / ti.sqrt(omega_F)
        d2FdQ2 = 2.0/3.0/ti.sqrt(omega_F) - 4.0/9.0 * self.Q_array[p]**2 * omega_F**(-1.5)

        gradQ_dyad_gradQ = gradQ.outer_product(gradQ)

        hess_g = dFdQ*hessQ + d2FdQ2*gradQ_dyad_gradQ


        return hess_g




    # Partial potential function / partial principal stresses / partial principal strains
    # [Input]: hess_g
    # [Output]: hess_potential_epsilon
    @ti.func
    def hess_potential_epsilon(self, hess_g):
        hess_g_eps = ti.Matrix.zero(float, 3, 3)
        for a, i, j in ti.static(ti.ndrange(3, 3, 3)):
            hess_g_eps[i, j] += hess_g[i, a] * self.elastic_a[None][a, j]

        return hess_g_eps




    @ti.func
    def update_J_no_bar(self, delta_J, p):
        self.J_no_bar_array[p] *= delta_J


    @ti.func
    def get_Kirchhoff_stress(self, p):
        # # old implementation
        # U, sig, V = ti.svd(self.F_elastic_array[p])
        # inv_sig = sig.inverse()
        # e = ti.Matrix.zero(float, 3, 3)
        # for d in ti.static(range(3)):
        #     e[d, d] = ti.log(sig[d, d])
        # stress = U @ (2 * self.lame_mu * inv_sig @ e + self.lame_lambda * e.trace() * inv_sig) @ V.transpose() # formula (26) in Klar et al., pk1 stress
        # stress = stress @ self.F_elastic_array[p].transpose() # Kirchhoff stress

        # return stress


        # new implementation
        U, sig, V = ti.svd(self.F_elastic_array[p])
        inv_sig = sig.inverse()
        e = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            e[d, d] = ti.log(sig[d, d]) # get principle logarithmic strain
        e_trace = e.trace()

        Kirchhoff_principal = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            Kirchhoff_principal[d, d] = self.lame_lambda * e_trace + 2 * self.lame_mu * e[d, d]

        Kirchhoff_stress = U @ (Kirchhoff_principal) @ U.transpose()

        return Kirchhoff_stress





    @ti.func
    def get_Cauchy_stress(self, p):
        # # old implementation
        # U, sig, V = ti.svd(self.F_elastic_array[p])
        # inv_sig = sig.inverse()
        # e = ti.Matrix.zero(float, 3, 3)
        # for d in ti.static(range(3)):
        #     e[d, d] = ti.log(sig[d, d])
        # stress = U @ (2 * self.lame_mu * inv_sig @ e + self.lame_lambda * e.trace() * inv_sig) @ V.transpose() # formula (26) in Klar et al., pk1 stress
        # stress = stress @ self.F_elastic_array[p].transpose() # Kirchhoff stress

        # return stress/self.J_array[p]



        # new implementation
        U, sig, V = ti.svd(self.F_elastic_array[p])
        inv_sig = sig.inverse()
        e = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            e[d, d] = ti.log(sig[d, d]) # get principle logarithmic strain
        e_trace = e.trace()

        Kirchhoff_principal = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            Kirchhoff_principal[d, d] = self.lame_lambda * e_trace + 2 * self.lame_mu * e[d, d]

        Kirchhoff_stress = U @ (Kirchhoff_principal) @ U.transpose()

        return Kirchhoff_stress/self.J_array[p]







    @ti.func
    def get_plastic_multiplier(self, p):
        return self.plastic_multiplier[p]

    @ti.func
    def get_plastic_rate(self, p):
        return self.plastic_rate[p]

    @ti.func
    def get_J(self, p):
        return self.J_array[p]

    @ti.func
    def get_J_no_bar(self, p):
        return self.J_no_bar_array[p]






@ti.kernel
def run_validation():
    # initialization
    my_material.initialize()

    # set initial deformation gradient
    initial_F = ti.Matrix.identity(float, 3)
    initial_F[0, 0] -= 0.01 #0.1
    initial_F[1, 1] -= 0.01 #0.1
    initial_F[2, 2] -= 0.01 #0.1
    # initial_F[0, 0] += 0.0001 #0.1
    # initial_F[1, 1] += 0.0001 #0.1
    # initial_F[2, 2] += 0.0001 #0.1

    my_material.update_deformation_gradient(initial_F, 0, 0.1)

    # cauchy_stress_3d = my_material.get_Kirchhoff_stress(0)
    # print(cauchy_stress_3d)

    Kirchhoff_stress_3d = my_material.get_Kirchhoff_stress(0)
    print(Kirchhoff_stress_3d)


    # add incremental strain
    incr_mag = 0.002 #-0.2 

    for j in range(1):
        for i in range(100):
        # for i in range(1000):
            print(i)
            delta_F = ti.Matrix.identity(float ,3)
            delta_F[2, 2] += incr_mag
            my_material.update_deformation_gradient(delta_F, 0, 0.1)

            
            Kirchhoff_stress_3d = my_material.get_Kirchhoff_stress(0)
            print(Kirchhoff_stress_3d)
            # if i == 9:
            #     break







# Validation
if __name__ == '__main__':
    my_Youngs = 1e3
    my_nu = 0.3
    my_friction_angle = 25 # degree
    my_cohesion = 0.001 #0.0 # seems non-zero cohesion has some problems
    my_mu2 = 0.5
    my_xi = 0.0
    my_implicit_rheology_flag = False
    my_shape_factor = 0.01

    my_material = DruckerPragerRheology(1, 3, my_Youngs, my_nu, my_friction_angle, my_cohesion, my_mu2, my_xi, my_implicit_rheology_flag, my_shape_factor)


    run_validation()









