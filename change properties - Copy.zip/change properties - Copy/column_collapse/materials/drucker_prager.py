import math
import taichi as ti
import numpy as np

# ti.init(arch=ti.gpu, default_fp=ti.f64)
ti.init(arch=ti.cpu, default_fp=ti.f64)

# constants
pi = math.pi

@ti.data_oriented
class DruckerPrager:
    def __init__(self,
                 n_particles, # number of particles
                 dim, # problem dimension, 2 = 2D (plain strain assumption), 3 = 3D
                 E, # Young's modulus
                 nu, # Poisson's ratio
                 friction_angle # friction angle in degree unit
                 ):
        self.n_particles = n_particles
        self.dim = dim
        self.E = E
        self.nu = nu
        self.lame_mu, self.lame_lambda = E / (2*(1+nu)), E*nu / ((1+nu) * (1-2*nu)) # Lame parameters
        self.friction_angle = friction_angle

        # Quantities declaration (they will be initialized in another funciton)
        self.F_elastic_array = ti.Matrix.field(3, 3, dtype = float, shape = n_particles)
        self.J_array = ti.field(dtype = float, shape = n_particles)
        self.friction_coeff_array = ti.field(dtype = float, shape = n_particles)
        self.plastic_multiplier = ti.field(dtype = float, shape = n_particles)


    # ============ MEMBER FUNCTIONS - taichi scope ============
    @ti.func
    def initialize(self):
        F_elastic_init = ti.Matrix.identity(float, 3)

        for p in range(self.n_particles):
            self.F_elastic_array[p] = F_elastic_init

            self.J_array[p] = 1.0

            self.friction_coeff_array[p] = 2.0*ti.sqrt(6)*ti.sin(self.friction_angle*pi/180) / (3-ti.sin(self.friction_angle*pi/180)) # B in Eq. (4.76) of Borja, Plasticity Modeling & Computation
            self.plastic_multiplier[p] = 0.0







    @ti.func
    def return_mapping(self, e_trial, p):

        # Calculate trial stress
        eps_v = e_trial.trace()
        tau_trial = self.lame_lambda * eps_v * ti.Matrix.identity(float, 3) + 2 * self.lame_mu * e_trial

        # Get P and S
        P = 1/3 * tau_trial.trace()
        S_trial = tau_trial - P * ti.Matrix.identity(float, 3)
        S_trial_norm = ti.sqrt(S_trial[0, 0] ** 2 + S_trial[1, 1] ** 2 + S_trial[2, 2] ** 2)
        Q_trial = ti.sqrt(3.0/2.0) * S_trial_norm

        new_e = ti.Matrix.zero(float, 3, 3)

        # return mapping
        yield_function = ti.sqrt(2.0/3.0) * Q_trial + self.friction_coeff_array[p] * P

        if yield_function <= 0: # elastic
            new_e = e_trial
        elif yield_function > 0 and e_trial.trace() > 0: # plasticity, return mapping to the tip
            delta_lambda = ti.sqrt(e_trial[0,0]**2 + e_trial[1,1]**2 + e_trial[2,2]**2) 

            new_e = ti.Matrix.zero(float, 3, 3)

            self.plastic_multiplier[p] += delta_lambda
            self.J_array[p] = 1.0

        elif yield_function > 0: # plasticity, radial return mapping with an dilation angle = 0
            delta_lambda = (yield_function) / (2 * self.lame_mu)

            n = ti.Matrix.zero(float, 3, 3)
            if S_trial_norm > 0:
                n = S_trial / S_trial_norm
            new_e = e_trial - delta_lambda * n

            self.plastic_multiplier[p] += delta_lambda

        return new_e






    @ti.func
    def update_deformation_gradient(self, delta_F, p):

        delta_F_3D = ti.Matrix.zero(float, 3, 3)
        if self.dim == 2:
            for i, j in ti.static(ti.ndrange(2, 2)):
                delta_F_3D[i, j] = delta_F[i, j]
            delta_F_3D[2, 2] = 1.0
        else:
            for i, j in ti.static(ti.ndrange(self.dim, self.dim)):
                delta_F_3D[i, j] = delta_F[i, j]

        # get trial elastic deformation gradient
        new_F_elastic_trial = delta_F_3D @ self.F_elastic_array[p]

        # update J
        delta_J = delta_F_3D.determinant()
        self.J_array[p] *= delta_J


        U, sig, V = ti.svd(new_F_elastic_trial)
        e = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            e[d, d] = ti.log(sig[d, d]) # principal logarithmic strain
        new_e = self.return_mapping(e, p)

        # TODO: hardening

        # get new elastic deformation gradient
        exp_new_e = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            exp_new_e[d, d] = ti.exp(new_e[d, d])
        new_F_elastic = U @ exp_new_e @ V.transpose()

        
        # update elastic deformation gradient
        self.F_elastic_array[p] = new_F_elastic







    @ti.func
    def get_Kirchhoff_stress(self, p):
        U, sig, V = ti.svd(self.F_elastic_array[p])
        inv_sig = sig.inverse()
        e = ti.Matrix.zero(float, 3, 3)
        for d in ti.static(range(3)):
            e[d, d] = ti.log(sig[d, d])
        stress = U @ (2 * self.lame_mu * inv_sig @ e + self.lame_lambda * e.trace() * inv_sig) @ V.transpose() # formula (26) in Klar et al., pk1 stress
        stress = stress @ self.F_elastic_array[p].transpose() # Kirchhoff stress

        return stress

    @ti.func
    def get_Cauchy_stress(self, p):
        Kirchhoff_stress = self.get_Kirchhoff_stress(p)

        return Kirchhoff_stress/self.J_array[p]

    @ti.func
    def get_plastic_multiplier(self, p):
        return self.plastic_multiplier[p]

    @ti.func
    def get_J(self, p):
        return self.J_array[p]











