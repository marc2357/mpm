# Dry sand column collapse


Dry sand column collapse example implemented in [**Taichi**](https://github.com/taichi-dev/taichi).

## Install
```shell
pip install numpy
pip install taichi 
```

## Code Structure

The code structure in each sub-file is:

```markdown
|-- solvers
		|-- main_function.py (Initialization, load step, post-processing control)
|-- materials
		|-- some_material.py 
|-- post_processing
		|-- post-processing files (in .ply format)
```

## How to run the code

1. cd to examples/specific_problem/solvers
2. Type: 
```markdown
python3 ./specific_solver.py
```